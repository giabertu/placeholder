import ProgressBar from "../components/ProgressBar";
import QuizCompanyName from "../components/QuizCompanyName";
import { SyntheticEvent, useEffect, useState } from 'react'

const initialTitle = 'I\'d like to speak to my mentor about ___________'
function Page2() {

  const [title, setTitle] = useState<string>(initialTitle)
  const [currentSelection, setCurrentSelection] = useState<number | null>(null)

  function handleButtonClick(event: React.MouseEvent<HTMLButtonElement, MouseEvent>) {
    const eventButton = event.target as HTMLButtonElement;

    const endOfTitle = eventButton.innerText.replace('> ', '');
    const beginningOfTitle = initialTitle.replace(/_/g, '');
    setTitle(beginningOfTitle + endOfTitle)
  }

  useEffect(() => {

  }, [])

  return (
    <div className="container flex-column">
      <QuizCompanyName />
      <div className="question-container flex-column">
        <ProgressBar value={30} />
        <div className="title-container flex-row">
          <h1 className='h1'>{title}</h1>
        </div>
        <div className="input-description-container flex-row">
          <div className="options-container flex-column">
            <button className="button-style"
              onClick={(event) => handleButtonClick(event)}>{">"} learning how to program</button>
            <button className="button-style"
              onClick={(event) => handleButtonClick(event)}>{">"} switching careers</button>
            <button className="button-style"
              onClick={(event) => handleButtonClick(event)}>{">"} finding my dream developer role</button>
            <button className="button-style"
              onClick={(event) => handleButtonClick(event)}>{">"} writing better code</button>
          </div>
          <div className="description-container">
            {currentSelection == 0 &&
              <p>Programming can be intimidating, and it can be
                difficult to know where to start. I'd like a mentor
                that can show me the ropes and give me some direction,
                or even teach me about a specific technology</p>
            }
          </div>
        </div>
      </div>
    </div>
  )
}


export default Page2;