function QuizCompanyName() {
  return (
    <h1>placeholder.io [Version 0.0.1]</h1>
  )
}

export default QuizCompanyName;